<?php
//modified by Mewburn Projects Pty Ltd

namespace PHPSTORM_META;

override(\Mockery::mock(0), map(["" => "@&\Mockery\MockInterface"]));
override(\Mockery::spy(0), map(["" => "@&\Mockery\MockInterface"]));
override(\Mockery::namedMock(0), map(["" => "@&\Mockery\MockInterface"]));
override(\Mockery::instanceMock(0), map(["" => "@&\Mockery\MockInterface"]));
override(\mock(0), map(["" => "@&\Mockery\MockInterface"]));
override(\spy(0), map(["" => "@&\Mockery\MockInterface"]));
override(\namedMock(0), map(["" => "@&\Mockery\MockInterface"]));
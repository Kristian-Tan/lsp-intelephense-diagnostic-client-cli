<?php

namespace Parle;

use Exception;
use Throwable;

class ParserException extends Exception implements Throwable {}

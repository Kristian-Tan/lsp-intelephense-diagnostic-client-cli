<?php

namespace RdKafka\Metadata;

class Broker
{
    public function getId() {}

    public function getHost() {}

    public function getPort() {}
}

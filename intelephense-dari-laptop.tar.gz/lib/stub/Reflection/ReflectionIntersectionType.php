<?php
//modified by Mewburn Projects Pty Ltd
use __IDE\Pure;

/**
 * @since 8.1
 */
class ReflectionIntersectionType extends ReflectionType
{
    /** @return ReflectionType[] */
    #[Pure]
    public function getTypes(): array {}
}

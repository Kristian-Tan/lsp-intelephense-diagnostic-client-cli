<?php

namespace parallel\Future\Error;

use parallel\Error;

class Cancelled extends Error {}

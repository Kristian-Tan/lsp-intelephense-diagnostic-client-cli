<?php

namespace parallel\Runtime\Type;

class Unavailable {}

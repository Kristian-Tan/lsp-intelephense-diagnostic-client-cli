<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class Killed extends Error {}

<?php

// Start of ZendUtils v.

function zem_get_extension_info_by_id() {}

function zem_get_extension_info_by_name() {}

function zem_get_extensions_info() {}

function zem_get_license_info() {}

function zend_is_configuration_changed() {}

function zend_set_configuration_changed() {}

// End of ZendUtils v.
